BELLA LUNA — FREE STARTER WEBSITE

Files:
- index.html
- style.css
- script.js

To publish for free:
1. Create a GitHub account.
2. Create a new public repository named bella-luna.
3. Upload these 3 files.
4. In Settings > Pages, choose Deploy from branch, select main, and save.
5. GitHub will give you a free https://...github.io website.

IMPORTANT:
- Replace the demo products, prices, Instagram and email with your real details.
- Replace the four PHOTO placeholders with your own product photos.
- The checkout button is intentionally not connected to payments. Connect a legitimate payment provider before taking customer payments.
